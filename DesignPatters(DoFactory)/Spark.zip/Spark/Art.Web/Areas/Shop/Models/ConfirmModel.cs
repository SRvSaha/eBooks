﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Art.Web.Areas.Shop.Models
{
    public class ConfirmModel
    {
        public int OrderNumber { get; set; }
    }
}