﻿using System.Web;
using System.Web.Mvc;

namespace Art.Web
{
    public class FilterConfig
    {
        public static void RegisterGlobalFilters(GlobalFilterCollection filters)
        {
            // not used

            // filters.Add(new HandleErrorAttribute());
        }
    }
}