using System;
using System.Collections.Generic;
using System.Text;
using System.Data.Common;
using System.Data;
using System.Dynamic;
using System.Transactions;
using System.Configuration;

namespace Art.Domain
{
    // Generated 07/24/2013 16:13:17

	// Add custom code inside partial class

    public partial class Db
    {
	}
}
