using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Art.Domain
{
    // Generated 07/24/2013 16:13:17

    // Add custom code inside partial classes

    public partial class UnitOfWork : IDisposable
    {
    }

	public partial class UnitOfWorkDistributed : IDisposable
    {
	}
}
