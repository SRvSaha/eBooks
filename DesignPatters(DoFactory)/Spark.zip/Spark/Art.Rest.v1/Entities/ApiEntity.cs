using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Art.Rest.v1
{
    // Generated 07/20/2013 16:40:13
	
    public class ApiEntity
    {
        public string Href { get; set; }
    }
}
