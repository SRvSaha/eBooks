﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Mvc;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Mvc;
using Mvc.Controllers;

namespace Mvc.Tests.Controllers
{
    [TestClass]
    public class HomeControllerTest
    {
        // not implemented in Pattern in Action.
        // see ShopControllerTest for a unit testing sample. 
    }
}
