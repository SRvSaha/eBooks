using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyTitle("Gang Of Four Design Patterns")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Data & Object Factory, LLC")]
[assembly: AssemblyProduct("")]
[assembly: AssemblyCopyright("Copyright � 2010 Data & Object Factory, LLC. All Rights Reserved.")]
[assembly: AssemblyTrademark("Design Pattern Framework is a trademark of Data & Object Factory.")]
[assembly: AssemblyCulture("")]        
[assembly: AssemblyVersion("4.0.*")]
[assembly: AssemblyDelaySign(false)]
[assembly: AssemblyKeyFile("")]
[assembly: AssemblyKeyName("")]
