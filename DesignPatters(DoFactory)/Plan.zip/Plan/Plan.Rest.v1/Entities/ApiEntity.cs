using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Plan.Rest.v1
{
    // Generated 07/26/2013 00:04:12
	
    public class ApiEntity
    {
        public string Href { get; set; }
    }
}
