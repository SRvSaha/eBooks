using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Plan.Domain
{
    // Generated 07/26/2013 00:00:42

	// Add custom code inside partial classes

    public partial class UnitOfWork : IDisposable
    {
    }

	public partial class UnitOfWorkDistributed : IDisposable
    {
	}
}
