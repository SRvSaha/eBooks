using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Reflection;
using System.Data;
using System.Threading;

namespace Plan.Domain
{
    // Generated 07/26/2013 00:00:42

	// Add custom code inside partial class

    public partial class Entity<T> where T : Entity<T>, new()
	{
	}
}
