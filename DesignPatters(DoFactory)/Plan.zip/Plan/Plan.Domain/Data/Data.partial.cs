using System;
using System.Collections.Generic;
using System.Text;
using System.Data.Common;
using System.Data;
using System.Dynamic;
using System.Transactions;
using System.Configuration;

namespace Plan.Domain
{
    // Generated 07/26/2013 00:00:42

	// Add custom code inside partial class

    public partial class Db
    {
	}
}
